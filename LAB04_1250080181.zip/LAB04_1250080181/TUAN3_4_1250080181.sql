
-- BẢNG MONHOC
CREATE TABLE MONHOC (
    MAMH NUMBER(8) PRIMARY KEY,
    TENMH VARCHAR2(50),
    HOCPHI NUMBER(9,2),
    MON_TRUOC NUMBER(8),
    NGUOITAO VARCHAR2(30),
    NGAYTAO DATE,
    NGUOISUA VARCHAR2(30),
    NGAYSUA DATE
);

-- BẢNG LOPHOC

CREATE TABLE LOPHOC (
    MALOP NUMBER(8) PRIMARY KEY,
    MAMH NUMBER(8),
    SOLOP NUMBER(3),
    NGAYBATDAU DATE,
    PHONG VARCHAR2(50),
    MAGV NUMBER(8),
    SISO NUMBER(3),
    NGUOITAO VARCHAR2(30),
    NGAYTAO DATE,
    NGUOISUA VARCHAR2(30),
    NGAYSUA DATE,
    CONSTRAINT FK_LOP_MON FOREIGN KEY (MAMH) REFERENCES MONHOC(MAMH)
);

-- BẢNG SINHVIEN 
CREATE TABLE SINHVIEN (
    MASV NUMBER(8) PRIMARY KEY,
    TEN VARCHAR2(25),
    HO VARCHAR2(25),
    DIACHI VARCHAR2(50),
    NGAYDK DATE,
    NGUOITAO VARCHAR2(30),
    NGAYTAO DATE,
    NGUOISUA VARCHAR2(30),
    NGAYSUA DATE
);

-- BẢNG GIANGVIEN 
CREATE TABLE GIANGVIEN (
    MAGV NUMBER(8) PRIMARY KEY,
    TEN VARCHAR2(25),
    HO VARCHAR2(25),
    DIACHI VARCHAR2(50),
    NGUOITAO VARCHAR2(30),
    NGAYTAO DATE,
    NGUOISUA VARCHAR2(30),
    NGAYSUA DATE
);

-- BẢNG DANGKY
CREATE TABLE DANGKY (
    MASV NUMBER(8),
    MALOP NUMBER(8),
    NGAYDK DATE,
    DIEM NUMBER(3),
    NGUOITAO VARCHAR2(30),
    NGAYTAO DATE,
    NGUOISUA VARCHAR2(30),
    NGAYSUA DATE,
    CONSTRAINT PK_DANGKY PRIMARY KEY (MASV, MALOP),
    CONSTRAINT FK_DK_SV FOREIGN KEY (MASV) REFERENCES SINHVIEN(MASV),
    CONSTRAINT FK_DK_LOP FOREIGN KEY (MALOP) REFERENCES LOPHOC(MALOP)
);

-- BẢNG DIEM 
CREATE TABLE DIEM (
    MASV NUMBER(8),
    MALOP NUMBER(8),
    DIEMSO NUMBER(3),
    GHICHU VARCHAR2(200),
    NGUOITAO VARCHAR2(30),
    NGAYTAO DATE,
    NGUOISUA VARCHAR2(30),
    NGAYSUA DATE,
    
    CONSTRAINT PK_DIEM PRIMARY KEY (MASV, MALOP),
    CONSTRAINT FK_DIEM_SV FOREIGN KEY (MASV) REFERENCES SINHVIEN(MASV),
    CONSTRAINT FK_DIEM_LOP FOREIGN KEY (MALOP) REFERENCES LOPHOC(MALOP)
);
-- ================= MONHOC =================
INSERT INTO MONHOC VALUES (101, 'Lap trinh Java', 3000000, NULL, USER, SYSDATE, USER, SYSDATE);
INSERT INTO MONHOC VALUES (102, 'Co so du lieu', 2500000, NULL, USER, SYSDATE, USER, SYSDATE);
INSERT INTO MONHOC VALUES (103, 'Tri tue nhan tao', 4000000, 101, USER, SYSDATE, USER, SYSDATE);
INSERT INTO MONHOC VALUES (104, 'Mang may tinh', 2800000, NULL, USER, SYSDATE, USER, SYSDATE);
INSERT INTO MONHOC VALUES (105, 'He dieu hanh', 2700000, NULL, USER, SYSDATE, USER, SYSDATE);

-- ================= GIANGVIEN =================
INSERT INTO GIANGVIEN VALUES (1, 'An', 'Nguyen Van', 'TP Ho Chi Minh', USER, SYSDATE, USER, SYSDATE);
INSERT INTO GIANGVIEN VALUES (2, 'Binh', 'Tran Thi', 'Ha Noi', USER, SYSDATE, USER, SYSDATE);
INSERT INTO GIANGVIEN VALUES (3, 'Cuong', 'Le Van', 'Da Nang', USER, SYSDATE, USER, SYSDATE);
INSERT INTO GIANGVIEN VALUES (4, 'Dung', 'Pham Thi', 'Can Tho', USER, SYSDATE, USER, SYSDATE);
INSERT INTO GIANGVIEN VALUES (5, 'Huy', 'Hoang Van', 'Hai Phong', USER, SYSDATE, USER, SYSDATE);

-- ================= SINHVIEN =================
INSERT INTO SINHVIEN VALUES (201, 'Nam', 'Le Van', 'TP Ho Chi Minh', SYSDATE, USER, SYSDATE, USER, SYSDATE);
INSERT INTO SINHVIEN VALUES (202, 'Hoa', 'Pham Thi', 'Ha Noi', SYSDATE, USER, SYSDATE, USER, SYSDATE);
INSERT INTO SINHVIEN VALUES (203, 'Minh', 'Vo Van', 'Da Nang', SYSDATE, USER, SYSDATE, USER, SYSDATE);
INSERT INTO SINHVIEN VALUES (204, 'Lan', 'Nguyen Thi', 'Can Tho', SYSDATE, USER, SYSDATE, USER, SYSDATE);
INSERT INTO SINHVIEN VALUES (205, 'Tuan', 'Tran Van', 'Binh Duong', SYSDATE, USER, SYSDATE, USER, SYSDATE);

-- ================= LOPHOC =================
INSERT INTO LOPHOC VALUES (301, 101, 1, SYSDATE, 'Phong A1', 1, 30, USER, SYSDATE, USER, SYSDATE);
INSERT INTO LOPHOC VALUES (302, 102, 1, SYSDATE, 'Phong B1', 2, 25, USER, SYSDATE, USER, SYSDATE);
INSERT INTO LOPHOC VALUES (303, 103, 1, SYSDATE, 'Phong C1', 3, 20, USER, SYSDATE, USER, SYSDATE);
INSERT INTO LOPHOC VALUES (304, 104, 1, SYSDATE, 'Phong D1', 4, 35, USER, SYSDATE, USER, SYSDATE);
INSERT INTO LOPHOC VALUES (305, 105, 1, SYSDATE, 'Phong E1', 5, 40, USER, SYSDATE, USER, SYSDATE);
INSERT INTO LOPHOC VALUES (306, 101, 2, SYSDATE, 'Phong A2', 1, 30, USER, SYSDATE, USER, SYSDATE);
INSERT INTO LOPHOC VALUES (307, 102, 2, SYSDATE, 'Phong B2', 1, 25, USER, SYSDATE, USER, SYSDATE);
INSERT INTO LOPHOC VALUES (308, 103, 2, SYSDATE, 'Phong C2', 1, 20, USER, SYSDATE, USER, SYSDATE);
INSERT INTO LOPHOC VALUES (309, 104, 2, SYSDATE, 'Phong D2', 1, 35, USER, SYSDATE, USER, SYSDATE);

COMMIT;

-- ================= DANGKY =================
INSERT INTO DANGKY VALUES (201, 301, SYSDATE, 85, USER, SYSDATE, USER, SYSDATE);
INSERT INTO DANGKY VALUES (201, 302, SYSDATE, 78, USER, SYSDATE, USER, SYSDATE);
INSERT INTO DANGKY VALUES (202, 301, SYSDATE, 90, USER, SYSDATE, USER, SYSDATE);
INSERT INTO DANGKY VALUES (202, 303, SYSDATE, 88, USER, SYSDATE, USER, SYSDATE);
INSERT INTO DANGKY VALUES (203, 302, SYSDATE, 70, USER, SYSDATE, USER, SYSDATE);
INSERT INTO DANGKY VALUES (204, 304, SYSDATE, 65, USER, SYSDATE, USER, SYSDATE);
INSERT INTO DANGKY VALUES (205, 305, SYSDATE, 80, USER, SYSDATE, USER, SYSDATE);

-- ================= DIEM =================
INSERT INTO DIEM VALUES (201, 301, 85, 'Hoc tot', USER, SYSDATE, USER, SYSDATE);
INSERT INTO DIEM VALUES (202, 301, 90, 'Xuat sac', USER, SYSDATE, USER, SYSDATE);
INSERT INTO DIEM VALUES (203, 302, 70, 'Trung binh', USER, SYSDATE, USER, SYSDATE);
INSERT INTO DIEM VALUES (204, 304, 65, 'Can co gang', USER, SYSDATE, USER, SYSDATE);
INSERT INTO DIEM VALUES (205, 305, 80, 'Kha', USER, SYSDATE, USER, SYSDATE);

COMMIT;
SET SERVEROUTPUT ON;

-- Thêm sinh viên mới
INSERT INTO SINHVIEN VALUES (206, 'A', 'Test', 'HCM', SYSDATE, USER, SYSDATE, USER, SYSDATE);
INSERT INTO SINHVIEN VALUES (207, 'B', 'Test', 'HCM', SYSDATE, USER, SYSDATE, USER, SYSDATE);
INSERT INTO SINHVIEN VALUES (208, 'C', 'Test', 'HCM', SYSDATE, USER, SYSDATE, USER, SYSDATE);
INSERT INTO SINHVIEN VALUES (209, 'D', 'Test', 'HCM', SYSDATE, USER, SYSDATE, USER, SYSDATE);
INSERT INTO SINHVIEN VALUES (210, 'E', 'Test', 'HCM', SYSDATE, USER, SYSDATE, USER, SYSDATE);
INSERT INTO SINHVIEN VALUES (211, 'F', 'Test', 'HCM', SYSDATE, USER, SYSDATE, USER, SYSDATE);
INSERT INTO SINHVIEN VALUES (212, 'G', 'Test', 'HCM', SYSDATE, USER, SYSDATE, USER, SYSDATE);
INSERT INTO SINHVIEN VALUES (213, 'H', 'Test', 'HCM', SYSDATE, USER, SYSDATE, USER, SYSDATE);
INSERT INTO SINHVIEN VALUES (214, 'I', 'Test', 'HCM', SYSDATE, USER, SYSDATE, USER, SYSDATE);
INSERT INTO SINHVIEN VALUES (215, 'K', 'Test', 'HCM', SYSDATE, USER, SYSDATE, USER, SYSDATE);
INSERT INTO SINHVIEN VALUES (216, 'L', 'Test', 'HCM', SYSDATE, USER, SYSDATE, USER, SYSDATE);
INSERT INTO SINHVIEN VALUES (217, 'M', 'Test', 'HCM', SYSDATE, USER, SYSDATE, USER, SYSDATE);
INSERT INTO SINHVIEN VALUES (218, 'N', 'Test', 'HCM', SYSDATE, USER, SYSDATE, USER, SYSDATE);
INSERT INTO SINHVIEN VALUES (219, 'O', 'Test', 'HCM', SYSDATE, USER, SYSDATE, USER, SYSDATE);
INSERT INTO SINHVIEN VALUES (220, 'P', 'Test', 'HCM', SYSDATE, USER, SYSDATE, USER, SYSDATE);

-- Đăng ký vào lớp 301 (môn 101)
INSERT INTO DANGKY VALUES (206, 301, SYSDATE, 80, USER, SYSDATE, USER, SYSDATE);
INSERT INTO DANGKY VALUES (207, 301, SYSDATE, 80, USER, SYSDATE, USER, SYSDATE);
INSERT INTO DANGKY VALUES (208, 301, SYSDATE, 80, USER, SYSDATE, USER, SYSDATE);
INSERT INTO DANGKY VALUES (209, 301, SYSDATE, 80, USER, SYSDATE, USER, SYSDATE);
INSERT INTO DANGKY VALUES (210, 301, SYSDATE, 80, USER, SYSDATE, USER, SYSDATE);
INSERT INTO DANGKY VALUES (211, 301, SYSDATE, 80, USER, SYSDATE, USER, SYSDATE);
INSERT INTO DANGKY VALUES (212, 301, SYSDATE, 80, USER, SYSDATE, USER, SYSDATE);
INSERT INTO DANGKY VALUES (213, 301, SYSDATE, 80, USER, SYSDATE, USER, SYSDATE);
INSERT INTO DANGKY VALUES (214, 301, SYSDATE, 80, USER, SYSDATE, USER, SYSDATE);
INSERT INTO DANGKY VALUES (215, 301, SYSDATE, 80, USER, SYSDATE, USER, SYSDATE);
INSERT INTO DANGKY VALUES (216, 301, SYSDATE, 80, USER, SYSDATE, USER, SYSDATE);
INSERT INTO DANGKY VALUES (217, 301, SYSDATE, 80, USER, SYSDATE, USER, SYSDATE);
INSERT INTO DANGKY VALUES (218, 301, SYSDATE, 80, USER, SYSDATE, USER, SYSDATE);
INSERT INTO DANGKY VALUES (219, 301, SYSDATE, 80, USER, SYSDATE, USER, SYSDATE);
INSERT INTO DANGKY VALUES (220, 301, SYSDATE, 80, USER, SYSDATE, USER, SYSDATE);

COMMIT;
--------------------------------BAITAP---------------------------

-- Câu 1a
CREATE TABLE Cau1 (
    ID NUMBER,
    NAME VARCHAR2(50)
);

-- Câu 1b
CREATE SEQUENCE Cau1Seq
START WITH 5
INCREMENT BY 5;

SET SERVEROUTPUT ON;

-- Câu 1c → 1j
DECLARE
    v_name VARCHAR2(50);
    v_id NUMBER;
BEGIN
    -- [d] Sinh viên đăng ký NHIỀU lớp nhất
    SELECT HO || ' ' || TEN
    INTO v_name
    FROM (
        SELECT sv.HO, sv.TEN
        FROM SINHVIEN sv
        JOIN DANGKY dk ON sv.MASV = dk.MASV
        GROUP BY sv.MASV, sv.HO, sv.TEN
        ORDER BY COUNT(*) DESC
    )
    WHERE ROWNUM = 1;

    INSERT INTO Cau1 VALUES (Cau1Seq.NEXTVAL, v_name);
    SAVEPOINT sp_a;

    -- [e] Sinh viên đăng ký ÍT lớp nhất
    SELECT HO || ' ' || TEN
    INTO v_name
    FROM (
        SELECT sv.HO, sv.TEN
        FROM SINHVIEN sv
        JOIN DANGKY dk ON sv.MASV = dk.MASV
        GROUP BY sv.MASV, sv.HO, sv.TEN
        ORDER BY COUNT(*) ASC
    )
    WHERE ROWNUM = 1;

    INSERT INTO Cau1 VALUES (Cau1Seq.NEXTVAL, v_name);
    SAVEPOINT sp_b;

    -- [f] Giảng viên dạy NHIỀU lớp nhất
    SELECT HO || ' ' || TEN
    INTO v_name
    FROM (
        SELECT gv.HO, gv.TEN
        FROM GIANGVIEN gv
        JOIN LOPHOC lh ON gv.MAGV = lh.MAGV
        GROUP BY gv.MAGV, gv.HO, gv.TEN
        ORDER BY COUNT(*) DESC
    )
    WHERE ROWNUM = 1;

    INSERT INTO Cau1 VALUES (Cau1Seq.NEXTVAL, v_name);
    SAVEPOINT sp_c;

    -- [g] Lấy ID vừa thêm
    SELECT ID INTO v_id
    FROM Cau1
    WHERE NAME = v_name AND ROWNUM = 1;

    DBMS_OUTPUT.PUT_LINE('ID giang vien nhieu lop: ' || v_id);

    -- [h] Rollback về Savepoint B
    ROLLBACK TO sp_b;

    -- [i] Giảng viên dạy ÍT lớp nhất (dùng lại v_id)
    SELECT HO || ' ' || TEN
    INTO v_name
    FROM (
        SELECT gv.HO, gv.TEN
        FROM GIANGVIEN gv
        JOIN LOPHOC lh ON gv.MAGV = lh.MAGV
        GROUP BY gv.MAGV, gv.HO, gv.TEN
        ORDER BY COUNT(*) ASC
    )
    WHERE ROWNUM = 1;

    INSERT INTO Cau1 VALUES (v_id, v_name);

    -- [j] Thêm lại GV dạy nhiều lớp nhất
    SELECT HO || ' ' || TEN
    INTO v_name
    FROM (
        SELECT gv.HO, gv.TEN
        FROM GIANGVIEN gv
        JOIN LOPHOC lh ON gv.MAGV = lh.MAGV
        GROUP BY gv.MAGV, gv.HO, gv.TEN
        ORDER BY COUNT(*) DESC
    )
    WHERE ROWNUM = 1;

    INSERT INTO Cau1 VALUES (Cau1Seq.NEXTVAL, v_name);

    COMMIT;

    DBMS_OUTPUT.PUT_LINE('Hoan tat! Chay: SELECT * FROM Cau1;');

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Khong tim thay du lieu!');
        ROLLBACK;

    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Loi: ' || SQLERRM);
        ROLLBACK;
END;
/
-----BAI 1 CÂU 2----------------------------------------------
SET SERVEROUTPUT ON;

DECLARE
    v_masv NUMBER := &ma_sinh_vien;
    v_ho VARCHAR2(25) := '&ho_sinh_vien';
    v_ten VARCHAR2(25) := '&ten_sinh_vien';
    v_diachi VARCHAR2(50) := '&dia_chi';

    v_hoten VARCHAR2(50);
    v_soluong NUMBER;

BEGIN
    -- Thử tìm sinh viên
    SELECT HO || ' ' || TEN
    INTO v_hoten
    FROM SINHVIEN
    WHERE MASV = v_masv;

    -- Nếu tìm thấy → đếm số lớp đã đăng ký
    SELECT COUNT(*)
    INTO v_soluong
    FROM DANGKY
    WHERE MASV = v_masv;

    DBMS_OUTPUT.PUT_LINE('Họ tên: ' || v_hoten);
    DBMS_OUTPUT.PUT_LINE('Số lớp đã đăng ký: ' || v_soluong);

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        -- Nếu không tồn tại → thêm mới
        DBMS_OUTPUT.PUT_LINE('Sinh viên chưa tồn tại. Đang thêm...');

        INSERT INTO SINHVIEN
        VALUES (v_masv, v_ten, v_ho, v_diachi, SYSDATE, USER, SYSDATE, USER, SYSDATE);

        COMMIT;

        DBMS_OUTPUT.PUT_LINE('Đã thêm sinh viên: ' || v_ho || ' ' || v_ten);

END;
/
--------------------------------BAI 2 CAI 1 -----------------------
SET SERVEROUTPUT ON;

DECLARE
    v_instructor_id NUMBER := &ma_giao_vien;
    v_so_lop NUMBER;
BEGIN
    -- Dem so lop giao vien dang day
    SELECT COUNT(*)
    INTO v_so_lop
    FROM LOPHOC
    WHERE MAGV = v_instructor_id;

    -- Phan nhanh theo ket qua
    IF v_so_lop >= 5 THEN
        DBMS_OUTPUT.PUT_LINE('Giao vien nay nen nghi ngoi!');
    ELSE
        DBMS_OUTPUT.PUT_LINE('So lop giao vien dang day: ' || v_so_lop);
    END IF;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Khong tim thay giao vien co ma: ' || v_instructor_id);
END;
/
------------------------------CAU 2 BAI 2 ----------------------
SET SERVEROUTPUT ON;

DECLARE
    v_sid NUMBER := &ma_sinh_vien;
    v_cid NUMBER := &ma_lop;
    v_score NUMBER;
    v_grade VARCHAR2(2);
    v_check NUMBER;
BEGIN
    -- Kiem tra sinh vien ton tai
    SELECT COUNT(*) INTO v_check
    FROM SINHVIEN 
    WHERE MASV = v_sid;

    IF v_check = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Loi: Ma sinh vien ' || v_sid || ' khong ton tai!');
        RETURN;
    END IF;

    -- Kiem tra lop ton tai
    SELECT COUNT(*) INTO v_check
    FROM LOPHOC 
    WHERE MALOP = v_cid;

    IF v_check = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Loi: Ma lop ' || v_cid || ' khong ton tai!');
        RETURN;
    END IF;

    -- Lay diem cua sinh vien trong lop
    SELECT DIEMSO
    INTO v_score
    FROM DIEM
    WHERE MASV = v_sid AND MALOP = v_cid;

    -- Quy doi diem so sang diem chu bang CASE
    CASE
        WHEN v_score >= 90 THEN v_grade := 'A';
        WHEN v_score >= 80 THEN v_grade := 'B';
        WHEN v_score >= 70 THEN v_grade := 'C';
        WHEN v_score >= 50 THEN v_grade := 'D';
        ELSE v_grade := 'F';
    END CASE;

    DBMS_OUTPUT.PUT_LINE('Diem so: ' || v_score || ' -> Diem chu: ' || v_grade);

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Sinh vien chua dang ky lop nay hoac chua co diem!');
END;
/
---------------------------------BAI 3---------------
SET SERVEROUTPUT ON;

DECLARE
-- Cursor 1: Duyet tung mon hoc
CURSOR cur_course IS
SELECT MAMH, TENMH
FROM MONHOC
ORDER BY MAMH;

-- Cursor 2: Lay lop hoc cua mot mon (co doi so)
CURSOR cur_class (p_mamh NUMBER) IS
SELECT lh.SOLOP,
       COUNT(dk.MASV) AS so_sv
FROM LOPHOC lh
LEFT JOIN DANGKY dk ON lh.MALOP = dk.MALOP
WHERE lh.MAMH = p_mamh
GROUP BY lh.SOLOP
ORDER BY lh.SOLOP;

v_mamh MONHOC.MAMH%TYPE;
v_tenmh MONHOC.TENMH%TYPE;
v_solop LOPHOC.SOLOP%TYPE;
v_count NUMBER;

BEGIN
-- Duyet cursor ngoai: tung mon hoc
OPEN cur_course;
LOOP
    FETCH cur_course INTO v_mamh, v_tenmh;
    EXIT WHEN cur_course%NOTFOUND;

    -- In mon hoc
    DBMS_OUTPUT.PUT_LINE(v_mamh || ' ' || v_tenmh);

    -- Mo cursor trong
    OPEN cur_class(v_mamh);
    LOOP
        FETCH cur_class INTO v_solop, v_count;
        EXIT WHEN cur_class%NOTFOUND;

        DBMS_OUTPUT.PUT_LINE('Lop: ' || v_solop ||
        ' co so luong sinh vien dang ki: ' || v_count);
    END LOOP;

    CLOSE cur_class;
END LOOP;

CLOSE cur_course;

EXCEPTION
    WHEN OTHERS THEN
        IF cur_course%ISOPEN THEN CLOSE cur_course; END IF;
        IF cur_class%ISOPEN THEN CLOSE cur_class; END IF;
        DBMS_OUTPUT.PUT_LINE('Loi: ' || SQLERRM);
END;
/
------------------------------------CÂU 4---------------------------
--4A
CREATE OR REPLACE PROCEDURE find_sname
(
    i_student_id IN SINHVIEN.MASV%TYPE,
    o_first_name OUT SINHVIEN.TEN%TYPE,
    o_last_name  OUT SINHVIEN.HO%TYPE
)
IS
BEGIN
    SELECT TEN, HO
    INTO o_first_name, o_last_name
    FROM SINHVIEN
    WHERE MASV = i_student_id;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        o_first_name := NULL;
        o_last_name := NULL;
        DBMS_OUTPUT.PUT_LINE('Khong tim thay sinh vien ID: ' || i_student_id);
END find_sname;
/
---4B
CREATE OR REPLACE PROCEDURE print_student_name
(
    i_student_id IN SINHVIEN.MASV%TYPE
)
IS
    v_first SINHVIEN.TEN%TYPE;
    v_last  SINHVIEN.HO%TYPE;
BEGIN
    -- Goi thu tuc tren
    find_sname(i_student_id, v_first, v_last);

    IF v_first IS NOT NULL OR v_last IS NOT NULL THEN
        DBMS_OUTPUT.PUT_LINE('Ho ten sinh vien: ' || v_last || ' ' || v_first);
    END IF;
END print_student_name;
/
BEGIN
    print_student_name(201);
END;
/
--CÂU 2
CREATE OR REPLACE PROCEDURE Discount
IS
BEGIN
    FOR rec IN (
        SELECT mh.MAMH, mh.TENMH, mh.HOCPHI
        FROM MONHOC mh
        WHERE (
            SELECT COUNT(*)
            FROM DANGKY dk
            JOIN LOPHOC lh ON dk.MALOP = lh.MALOP
            WHERE lh.MAMH = mh.MAMH
        ) > 15
    ) LOOP

        -- Giam 5%
        UPDATE MONHOC
        SET HOCPHI = HOCPHI * 0.95
        WHERE MAMH = rec.MAMH;

        DBMS_OUTPUT.PUT_LINE('Da giam gia mon hoc: ' || rec.TENMH
        || ' | Gia cu: ' || rec.HOCPHI
        || ' | Gia moi: ' || ROUND(rec.HOCPHI * 0.95, 2));
    END LOOP;

    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Hoan tat giam gia.');

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Loi: ' || SQLERRM);
END Discount;
/
BEGIN
    Discount;
END;
/
--CÂU 4 (3)
CREATE OR REPLACE FUNCTION Total_cost_for_student
(
    p_student_id IN SINHVIEN.MASV%TYPE
)
RETURN NUMBER
IS
    v_total NUMBER;
    v_check NUMBER;
BEGIN
    -- Kiem tra sinh vien ton tai
    SELECT COUNT(*) INTO v_check
    FROM SINHVIEN
    WHERE MASV = p_student_id;

    IF v_check = 0 THEN
        RETURN NULL;
    END IF;

    -- Tinh tong hoc phi
    SELECT NVL(SUM(mh.HOCPHI), 0)
    INTO v_total
    FROM DANGKY dk
    JOIN LOPHOC lh ON dk.MALOP = lh.MALOP
    JOIN MONHOC mh ON lh.MAMH = mh.MAMH
    WHERE dk.MASV = p_student_id;

    RETURN v_total;

EXCEPTION
    WHEN OTHERS THEN
        RETURN NULL;
END Total_cost_for_student;
/
BEGIN
    DBMS_OUTPUT.PUT_LINE('Tong chi phi: ' || Total_cost_for_student(201));
END;
/
CREATE OR REPLACE TRIGGER trg_monhoc_audit
BEFORE INSERT OR UPDATE ON MONHOC
FOR EACH ROW
BEGIN
    IF INSERTING THEN
        :NEW.NGUOITAO := USER;
        :NEW.NGAYTAO := SYSDATE;
    END IF;

    :NEW.NGUOISUA := USER;
    :NEW.NGAYSUA := SYSDATE;
END;
/
CREATE OR REPLACE TRIGGER trg_lophoc_audit
BEFORE INSERT OR UPDATE ON LOPHOC
FOR EACH ROW
BEGIN
    IF INSERTING THEN
        :NEW.NGUOITAO := USER;
        :NEW.NGAYTAO := SYSDATE;
    END IF;

    :NEW.NGUOISUA := USER;
    :NEW.NGAYSUA := SYSDATE;
END;
/
CREATE OR REPLACE TRIGGER trg_sinhvien_audit
BEFORE INSERT OR UPDATE ON SINHVIEN
FOR EACH ROW
BEGIN
    IF INSERTING THEN
        :NEW.NGUOITAO := USER;
        :NEW.NGAYTAO := SYSDATE;
    END IF;

    :NEW.NGUOISUA := USER;
    :NEW.NGAYSUA := SYSDATE;
END;
/
CREATE OR REPLACE TRIGGER trg_giangvien_audit
BEFORE INSERT OR UPDATE ON GIANGVIEN
FOR EACH ROW
BEGIN
    IF INSERTING THEN
        :NEW.NGUOITAO := USER;
        :NEW.NGAYTAO := SYSDATE;
    END IF;

    :NEW.NGUOISUA := USER;
    :NEW.NGAYSUA := SYSDATE;
END;
/
CREATE OR REPLACE TRIGGER trg_dangky_audit
BEFORE INSERT OR UPDATE ON DANGKY
FOR EACH ROW
BEGIN
    IF INSERTING THEN
        :NEW.NGUOITAO := USER;
        :NEW.NGAYTAO := SYSDATE;
    END IF;

    :NEW.NGUOISUA := USER;
    :NEW.NGAYSUA := SYSDATE;
END;
/
CREATE OR REPLACE TRIGGER trg_diem_audit
BEFORE INSERT OR UPDATE ON DIEM
FOR EACH ROW
BEGIN
    IF INSERTING THEN
        :NEW.NGUOITAO := USER;
        :NEW.NGAYTAO := SYSDATE;
    END IF;

    :NEW.NGUOISUA := USER;
    :NEW.NGAYSUA := SYSDATE;
END;
/

CREATE OR REPLACE TRIGGER trg_max_dangky
BEFORE INSERT ON DANGKY
FOR EACH ROW
DECLARE
    v_so_lop NUMBER;
BEGIN
    -- Dem so lop sinh vien da dang ky
    SELECT COUNT(*)
    INTO v_so_lop
    FROM DANGKY
    WHERE MASV = :NEW.MASV;

    -- Neu >= 3 thi chan
    IF v_so_lop >= 3 THEN
        RAISE_APPLICATION_ERROR(
            -20001,
            'Sinh vien ' || :NEW.MASV ||
            ' da dang ky du 3 lop! Khong the dang ky them.'
        );
    END IF;
END;
/
INSERT INTO DANGKY VALUES (201, 303, SYSDATE, 80, USER, SYSDATE, USER, SYSDATE);
INSERT INTO DANGKY VALUES (201, 304, SYSDATE, 80, USER, SYSDATE, USER, SYSDATE);
--==================================TUAN 4====================================
--Câu 1.1: Tạo view vw_course_summary - thông tin tổng quan môn học
CREATE OR REPLACE VIEW vw_course_summary AS
SELECT mh.MAMH,
       mh.TENMH,
       mh.HOCPHI,
       COUNT(DISTINCT lh.MALOP) AS so_lop,
       COUNT(dk.MASV) AS tong_sv
FROM MONHOC mh
LEFT JOIN LOPHOC lh ON mh.MAMH = lh.MAMH
LEFT JOIN DANGKY dk ON lh.MALOP = dk.MALOP
GROUP BY mh.MAMH, mh.TENMH, mh.HOCPHI
ORDER BY tong_sv DESC;

SELECT * FROM vw_course_summary;
--Câu 1.2: Tạo view vw_student_status - thông tin sinh viên và tình trạng học tập
CREATE OR REPLACE VIEW vw_student_status AS
SELECT sv.MASV,
       sv.HO || ' ' || sv.TEN AS ho_ten,
       COUNT(dk.MALOP) AS so_lop_hoc,
       NVL(SUM(mh.HOCPHI), 0) AS tong_hoc_phi,
       ROUND(AVG(dk.DIEM), 2) AS diem_tb
FROM SINHVIEN sv
JOIN DANGKY dk ON sv.MASV = dk.MASV
JOIN LOPHOC lh ON dk.MALOP = lh.MALOP
JOIN MONHOC mh ON lh.MAMH = mh.MAMH
GROUP BY sv.MASV, sv.HO, sv.TEN
HAVING COUNT(dk.MALOP) >= 1
ORDER BY sv.MASV;

SELECT * FROM vw_student_status;
--Câu 1.3: Tạo view vw_class_availability - lớp học còn chỗ trống
CREATE OR REPLACE VIEW vw_class_availability AS
SELECT lh.MALOP,
       lh.MAMH,
       mh.TENMH,
       gv.HO || ' ' || gv.TEN AS ten_giao_vien,
       lh.SISO AS suc_chua,
       COUNT(dk.MASV) AS so_da_dk,
       lh.SISO - COUNT(dk.MASV) AS cho_trong,
       CASE
           WHEN lh.SISO - COUNT(dk.MASV) > 0 THEN 'Con cho'
           ELSE 'Het cho'
       END AS trang_thai
FROM LOPHOC lh
JOIN MONHOC mh ON lh.MAMH = mh.MAMH
JOIN GIANGVIEN gv ON lh.MAGV = gv.MAGV
LEFT JOIN DANGKY dk ON lh.MALOP = dk.MALOP
GROUP BY lh.MALOP, lh.MAMH, mh.TENMH,
         gv.HO, gv.TEN, lh.SISO
HAVING lh.SISO - COUNT(dk.MASV) > 0
ORDER BY lh.MALOP;

SELECT * FROM vw_class_availability;
--Câu 1.4: Tạo view vw_top_courses - chỉ đọc, top 5 môn được đăng ký nhiều nhất
CREATE OR REPLACE VIEW vw_top_courses AS
SELECT MAMH, TENMH, HOCPHI, tong_dk, hang
FROM (
    SELECT mh.MAMH,
           mh.TENMH,
           mh.HOCPHI,
           COUNT(dk.MASV) AS tong_dk,
           RANK() OVER (ORDER BY COUNT(dk.MASV) DESC) AS hang
    FROM MONHOC mh
    LEFT JOIN LOPHOC lh ON mh.MAMH = lh.MAMH
    LEFT JOIN DANGKY dk ON lh.MALOP = dk.MALOP
    GROUP BY mh.MAMH, mh.TENMH, mh.HOCPHI
) W
WHERE hang <= 5
ORDER BY hang
WITH READ ONLY;

SELECT * FROM vw_top_courses;
INSERT INTO vw_top_courses (MAMH, TENMH, HOCPHI)
VALUES (999, 'Test', 100);
--Câu 1.5: Tạo view vw_pending_enrollment với WITH CHECK OPTION và
--kiểm tra

CREATE OR REPLACE VIEW vw_pending_enrollment AS
SELECT MASV,
       MALOP,
       NGAYDK,
       DIEM,
       NGUOITAO,
       NGAYTAO,
       NGUOISUA,
       NGAYSUA
FROM DANGKY
WHERE DIEM IS NULL
WITH CHECK OPTION;
SELECT * FROM vw_pending_enrollment;
INSERT INTO DANGKY
(MASV, MALOP, NGAYDK, DIEM, NGUOITAO, NGAYTAO, NGUOISUA, NGAYSUA)
VALUES (999, 301, SYSDATE, NULL, USER, SYSDATE, USER, SYSDATE);
--
CREATE OR REPLACE PROCEDURE enroll_student
(
    p_masv IN NUMBER,
    p_malop IN NUMBER
)
IS
    v_check NUMBER;
    v_siso NUMBER;
    v_dadangky NUMBER;
BEGIN
    -- DK1: Sinh vien phai ton tai
    SELECT COUNT(*) INTO v_check
    FROM SINHVIEN
    WHERE MASV = p_masv;

    IF v_check = 0 THEN
        DBMS_OUTPUT.PUT_LINE('[LOI] Sinh vien ' || p_masv || ' khong ton tai!');
        RETURN;
    END IF;

    -- DK2: Lop hoc phai ton tai
    SELECT COUNT(*) INTO v_check
    FROM LOPHOC
    WHERE MALOP = p_malop;

    IF v_check = 0 THEN
        DBMS_OUTPUT.PUT_LINE('[LOI] Lop hoc ' || p_malop || ' khong ton tai!');
        RETURN;
    END IF;

    -- DK3: Kiem tra con cho trong
    SELECT SISO INTO v_siso
    FROM LOPHOC
    WHERE MALOP = p_malop;

    SELECT COUNT(*) INTO v_dadangky
    FROM DANGKY
    WHERE MALOP = p_malop;

    IF v_dadangky >= v_siso THEN
        DBMS_OUTPUT.PUT_LINE('[LOI] Lop ' || p_malop || ' da day! (' 
        || v_dadangky || '/' || v_siso || ')');
        RETURN;
    END IF;

    -- DK4: Sinh vien chua dang ky lop nay
    SELECT COUNT(*) INTO v_check
    FROM DANGKY
    WHERE MASV = p_masv AND MALOP = p_malop;

    IF v_check > 0 THEN
        DBMS_OUTPUT.PUT_LINE('[LOI] Sinh vien da dang ky lop nay roi!');
        RETURN;
    END IF;

    -- DK5: Sinh vien chua qua 3 lop
    SELECT COUNT(*) INTO v_check
    FROM DANGKY
    WHERE MASV = p_masv;

    IF v_check >= 3 THEN
        DBMS_OUTPUT.PUT_LINE('[LOI] Sinh vien da dang ky du 3 lop!');
        RETURN;
    END IF;

    -- Tat ca OK: INSERT
    INSERT INTO DANGKY
    (MASV, MALOP, NGAYDK, DIEM, NGUOITAO, NGAYTAO, NGUOISUA, NGAYSUA)
    VALUES
    (p_masv, p_malop, SYSDATE, NULL, USER, SYSDATE, USER, SYSDATE);

    COMMIT;

    DBMS_OUTPUT.PUT_LINE('[OK] Dang ky thanh cong! SV ' 
    || p_masv || ' -> Lop ' || p_malop);

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('[LOI HE THONG] ' || SQLERRM);
END enroll_student;
/
SET SERVEROUTPUT ON;

BEGIN
  enroll_student(201, 301); 
  enroll_student(202, 302); 
  enroll_student(999, 301); 
  enroll_student(201, 999); 
END;
/
--
CREATE OR REPLACE PROCEDURE update_final_grade
(
    p_masv IN NUMBER,
    p_malop IN NUMBER,
    p_diem IN NUMBER
)
IS
    v_check NUMBER;
    v_old_diem NUMBER;
BEGIN
    -- Kiem tra diem hop le
    IF p_diem < 0 OR p_diem > 100 THEN
        DBMS_OUTPUT.PUT_LINE('[LOI] Diem khong hop le! (0-100)');
        RETURN;
    END IF;

    -- Kiem tra sinh vien da dang ky lop
    SELECT COUNT(*) INTO v_check
    FROM DANGKY
    WHERE MASV = p_masv AND MALOP = p_malop;

    IF v_check = 0 THEN
        DBMS_OUTPUT.PUT_LINE('[LOI] Sinh vien chua dang ky lop nay!');
        RETURN;
    END IF;

    -- Luu diem cu
    SELECT DIEM INTO v_old_diem
    FROM DANGKY
    WHERE MASV = p_masv AND MALOP = p_malop;

    -- Cap nhat bang DANGKY
    UPDATE DANGKY
    SET DIEM = p_diem,
        NGUOISUA = USER,
        NGAYSUA = SYSDATE
    WHERE MASV = p_masv AND MALOP = p_malop;

    -- Dong bo sang bang DIEM (MERGE)
    MERGE INTO DIEM d
    USING (SELECT p_masv AS masv, p_malop AS malop FROM DUAL) src
    ON (d.MASV = src.masv AND d.MALOP = src.malop)
    WHEN MATCHED THEN
        UPDATE SET d.DIEMSO = p_diem,
                   d.NGUOISUA = USER,
                   d.NGAYSUA = SYSDATE
    WHEN NOT MATCHED THEN
        INSERT (MASV, MALOP, DIEMSO, NGUOITAO, NGAYTAO, NGUOISUA, NGAYSUA)
        VALUES (p_masv, p_malop, p_diem, USER, SYSDATE, USER, SYSDATE);

    COMMIT;

    DBMS_OUTPUT.PUT_LINE('[OK] Cap nhat diem SV ' || p_masv 
    || ' lop ' || p_malop
    || ': Cu=' || NVL(TO_CHAR(v_old_diem),'NULL') 
    || ' -> Moi=' || p_diem);

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('[LOI] ' || SQLERRM);
END update_final_grade;
/

SET SERVEROUTPUT ON;

BEGIN
  update_final_grade(201, 301, 95); 
  update_final_grade(201, 301, 150);
  update_final_grade(999, 301, 80); 
END;
/
--------------------------------------------------
CREATE OR REPLACE PROCEDURE transfer_student
(
    p_masv IN NUMBER,
    p_lop_cu IN NUMBER,
    p_lop_moi IN NUMBER
)
IS
    v_check NUMBER;
    v_siso NUMBER;
    v_dadangky NUMBER;
BEGIN
    -- DK1: Sinh vien dang hoc lop cu
    SELECT COUNT(*) INTO v_check
    FROM DANGKY
    WHERE MASV = p_masv AND MALOP = p_lop_cu;

    IF v_check = 0 THEN
        DBMS_OUTPUT.PUT_LINE('[LOI] Sinh vien khong dang hoc lop ' || p_lop_cu);
        RETURN;
    END IF;

    -- DK2: Lop moi con cho trong
    SELECT SISO INTO v_siso
    FROM LOPHOC
    WHERE MALOP = p_lop_moi;

    SELECT COUNT(*) INTO v_dadangky
    FROM DANGKY
    WHERE MALOP = p_lop_moi;

    IF v_dadangky >= v_siso THEN
        DBMS_OUTPUT.PUT_LINE('[LOI] Lop moi ' || p_lop_moi || ' da day!');
        RETURN;
    END IF;

    -- DK3: Sinh vien chua o lop moi
    SELECT COUNT(*) INTO v_check
    FROM DANGKY
    WHERE MASV = p_masv AND MALOP = p_lop_moi;

    IF v_check > 0 THEN
        DBMS_OUTPUT.PUT_LINE('[LOI] Sinh vien da o trong lop moi roi!');
        RETURN;
    END IF;

    -- ===== Thuc hien chuyen lop =====
    SAVEPOINT sp_truoc_chuyen;

    -- Buoc 1: Xoa lop cu
    DELETE FROM DANGKY
    WHERE MASV = p_masv AND MALOP = p_lop_cu;

    SAVEPOINT sp_sau_xoa;

    -- Buoc 2: Them vao lop moi
    INSERT INTO DANGKY
    (MASV, MALOP, NGAYDK, DIEM, NGUOITAO, NGAYTAO, NGUOISUA, NGAYSUA)
    VALUES
    (p_masv, p_lop_moi, SYSDATE, NULL, USER, SYSDATE, USER, SYSDATE);

    COMMIT;

    DBMS_OUTPUT.PUT_LINE('[OK] Da chuyen SV ' || p_masv
    || ' tu lop ' || p_lop_cu
    || ' sang lop ' || p_lop_moi);

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK TO sp_truoc_chuyen;
        DBMS_OUTPUT.PUT_LINE('[LOI] Chuyen lop that bai: ' || SQLERRM);
        DBMS_OUTPUT.PUT_LINE('Da rollback ve trang thai ban dau.');
END transfer_student;
/
SET SERVEROUTPUT ON;

BEGIN
  transfer_student(201, 301, 302); -- hop le
END;
/
--------------------------------
CREATE OR REPLACE PROCEDURE report_class_detail
(p_malop IN NUMBER)
IS
    v_check NUMBER;
    v_mon VARCHAR2(50);
    v_mamh NUMBER;
    v_gv VARCHAR2(50);
    v_phong VARCHAR2(50);
    v_siso NUMBER;
    v_stt NUMBER := 0;
    v_tong NUMBER := 0;
    v_sum_d NUMBER := 0;
    v_co_d NUMBER := 0;
    v_grade_txt VARCHAR2(15);
BEGIN
    -- Kiem tra lop ton tai
    SELECT COUNT(*) INTO v_check
    FROM LOPHOC
    WHERE MALOP = p_malop;

    IF v_check = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Lop hoc ' || p_malop || ' khong ton tai!');
        RETURN;
    END IF;

    -- Lay thong tin lop
    SELECT mh.TENMH, mh.MAMH,
           gv.HO || ' ' || gv.TEN,
           lh.PHONG, lh.SISO
    INTO v_mon, v_mamh, v_gv, v_phong, v_siso
    FROM LOPHOC lh
    JOIN MONHOC mh ON lh.MAMH = mh.MAMH
    JOIN GIANGVIEN gv ON lh.MAGV = gv.MAGV
    WHERE lh.MALOP = p_malop;

    -- In header
    DBMS_OUTPUT.PUT_LINE('=== BAO CAO LOP HOC: ' || p_malop || ' ===');
    DBMS_OUTPUT.PUT_LINE('Mon hoc : ' || v_mamh || ' - ' || v_mon);
    DBMS_OUTPUT.PUT_LINE('Giao vien: ' || v_gv);
    DBMS_OUTPUT.PUT_LINE('Phong hoc: ' || NVL(v_phong, 'Chua xep phong'));
    DBMS_OUTPUT.PUT_LINE('Suc chua : ' || v_siso || ' cho');
    DBMS_OUTPUT.PUT_LINE(RPAD('-',50,'-'));
    DBMS_OUTPUT.PUT_LINE('DANH SACH SINH VIEN:');
    DBMS_OUTPUT.PUT_LINE(RPAD('STT',4) || ' | ' || RPAD('Ho Ten',20) ||
                         ' | ' || LPAD('Diem',8) || ' | Xep loai');
    DBMS_OUTPUT.PUT_LINE(RPAD('-',50,'-'));

    -- Cursor loop
    FOR rec IN (
        SELECT sv.HO || ' ' || sv.TEN AS ho_ten,
               dk.DIEM
        FROM DANGKY dk
        JOIN SINHVIEN sv ON dk.MASV = sv.MASV
        WHERE dk.MALOP = p_malop
        ORDER BY sv.HO, sv.TEN
    ) LOOP
        v_stt := v_stt + 1;
        v_tong := v_tong + 1;

        -- Xep loai
        IF rec.DIEM IS NULL THEN
            v_grade_txt := 'Chua co diem';
        ELSIF rec.DIEM >= 90 THEN
            v_grade_txt := 'A';
            v_sum_d := v_sum_d + rec.DIEM; v_co_d := v_co_d + 1;
        ELSIF rec.DIEM >= 80 THEN
            v_grade_txt := 'B';
            v_sum_d := v_sum_d + rec.DIEM; v_co_d := v_co_d + 1;
        ELSIF rec.DIEM >= 70 THEN
            v_grade_txt := 'C';
            v_sum_d := v_sum_d + rec.DIEM; v_co_d := v_co_d + 1;
        ELSIF rec.DIEM >= 50 THEN
            v_grade_txt := 'D';
            v_sum_d := v_sum_d + rec.DIEM; v_co_d := v_co_d + 1;
        ELSE
            v_grade_txt := 'F';
            v_sum_d := v_sum_d + rec.DIEM; v_co_d := v_co_d + 1;
        END IF;

        DBMS_OUTPUT.PUT_LINE(
            LPAD(v_stt, 3) || ' | ' ||
            RPAD(rec.ho_ten, 20) || ' | ' ||
            LPAD(NVL(TO_CHAR(rec.DIEM),'NULL'), 7) || ' | ' ||
            v_grade_txt
        );
    END LOOP;

    -- Footer
    DBMS_OUTPUT.PUT_LINE(RPAD('-',50,'-'));
    DBMS_OUTPUT.PUT_LINE('Tong so sinh vien : ' || v_tong);

    IF v_co_d > 0 THEN
        DBMS_OUTPUT.PUT_LINE('Diem trung binh lop: '
        || ROUND(v_sum_d / v_co_d, 2));
    ELSE
        DBMS_OUTPUT.PUT_LINE('Diem trung binh lop: Chua co diem');
    END IF;

END report_class_detail;
/

SET SERVEROUTPUT ON;

BEGIN
  report_class_detail(301);
END;
/
-------------------------------------
CREATE OR REPLACE PROCEDURE sync_grade_from_enrollment
IS
    v_check NUMBER;
    v_dem_insert NUMBER := 0;
    v_dem_update NUMBER := 0;
BEGIN
    FOR rec IN (
        SELECT MASV, MALOP, DIEM
        FROM DANGKY
        WHERE DIEM IS NOT NULL
    ) LOOP

        -- Kiem tra trong DIEM da co chua
        SELECT COUNT(*) INTO v_check
        FROM DIEM
        WHERE MASV = rec.MASV AND MALOP = rec.MALOP;

        IF v_check = 0 THEN
            -- Chua co -> INSERT
            INSERT INTO DIEM
            (MASV, MALOP, DIEMSO, NGUOITAO, NGAYTAO, NGUOISUA, NGAYSUA)
            VALUES
            (rec.MASV, rec.MALOP, rec.DIEM,
             USER, SYSDATE, USER, SYSDATE);

            v_dem_insert := v_dem_insert + 1;

        ELSE
            -- Da co -> UPDATE
            UPDATE DIEM
            SET DIEMSO = rec.DIEM,
                NGUOISUA = USER,
                NGAYSUA = SYSDATE
            WHERE MASV = rec.MASV AND MALOP = rec.MALOP;

            v_dem_update := v_dem_update + 1;
        END IF;

    END LOOP;

    COMMIT;

    DBMS_OUTPUT.PUT_LINE('[OK] Dong bo hoan tat!');
    DBMS_OUTPUT.PUT_LINE(' So ban ghi INSERT moi : ' || v_dem_insert);
    DBMS_OUTPUT.PUT_LINE(' So ban ghi UPDATE     : ' || v_dem_update);

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('[LOI] ' || SQLERRM);
END sync_grade_from_enrollment;
/

SET SERVEROUTPUT ON;

BEGIN
  sync_grade_from_enrollment;
END;
/
---------------------------------------
CREATE OR REPLACE TRIGGER trg_check_capacity
BEFORE INSERT ON DANGKY
FOR EACH ROW
DECLARE
    v_siso NUMBER;
    v_dadangky NUMBER;
BEGIN
    -- Lay suc chua lop
    SELECT SISO INTO v_siso
    FROM LOPHOC
    WHERE MALOP = :NEW.MALOP;

    -- Dem so SV da dang ky
    SELECT COUNT(*) INTO v_dadangky
    FROM DANGKY
    WHERE MALOP = :NEW.MALOP;

    -- Chan neu lop da day
    IF v_dadangky >= v_siso THEN
        RAISE_APPLICATION_ERROR(
            -20010,
            'LOI: Lop ' || :NEW.MALOP || ' da day! ('
            || v_dadangky || '/' || v_siso || ')'
        );
    END IF;
END;
/

INSERT INTO DANGKY
VALUES (201, 301, SYSDATE, NULL, USER, SYSDATE, USER, SYSDATE);
--------------------------------------------------
CREATE TABLE NHATKY_DIEM (
    LOG_ID NUMBER GENERATED ALWAYS AS IDENTITY,
    MASV NUMBER(8),
    MALOP NUMBER(8),
    DIEM_CU NUMBER(3),
    DIEM_MOI NUMBER(3),
    NGUOISUA VARCHAR2(30),
    THOIGIAN DATE
);

CREATE OR REPLACE TRIGGER trg_grade_audit_log
AFTER UPDATE OF DIEM ON DANGKY
FOR EACH ROW
BEGIN
    -- Chi ghi log khi diem THUC SU thay doi
    IF (:OLD.DIEM IS NULL AND :NEW.DIEM IS NOT NULL)
    OR (:OLD.DIEM IS NOT NULL AND :NEW.DIEM IS NULL)
    OR (:OLD.DIEM != :NEW.DIEM)
    THEN
        INSERT INTO NHATKY_DIEM
        (MASV, MALOP, DIEM_CU, DIEM_MOI, NGUOISUA, THOIGIAN)
        VALUES
        (:OLD.MASV, :OLD.MALOP, :OLD.DIEM,
         :NEW.DIEM, USER, SYSDATE);
    END IF;
END;
/

UPDATE DANGKY
SET DIEM = 80
WHERE MASV = 201 AND MALOP = 301;

COMMIT;

SELECT * FROM NHATKY_DIEM;
----------------------------------------------------------
CREATE OR REPLACE TRIGGER trg_prevent_course_delete
BEFORE DELETE ON MONHOC
FOR EACH ROW
DECLARE
    v_so_lop NUMBER;
BEGIN
    -- Dem so lop thuoc mon hoc nay
    SELECT COUNT(*) INTO v_so_lop
    FROM LOPHOC
    WHERE MAMH = :OLD.MAMH;

    -- Neu con lop thi chan xoa
    IF v_so_lop > 0 THEN
        RAISE_APPLICATION_ERROR(
            -20020,
            'Khong the xoa mon hoc ' || :OLD.MAMH ||
            ' (' || :OLD.TENMH || ') ' ||
            'vi con ' || v_so_lop || ' lop hoc dang ton tai!'
        );
    END IF;

    -- Neu = 0 → Oracle tu xoa binh thuong
END;
/

DELETE FROM MONHOC
WHERE MAMH = 101;

INSERT INTO MONHOC
VALUES (999, 'Test xoa', 1000000, NULL, USER, SYSDATE, USER, SYSDATE);

DELETE FROM MONHOC
WHERE MAMH = 999;
-----------------------------------------------------------
CREATE TABLE class_grade_summary (
    classid NUMBER(8) PRIMARY KEY,
    so_sv NUMBER,
    diem_tb NUMBER(5,2),
    diem_cao_nhat NUMBER(3),
    diem_thap_nhat NUMBER(3),
    cap_nhat_luc DATE
);

CREATE OR REPLACE TRIGGER trg_update_grade_summary
AFTER INSERT OR UPDATE OR DELETE ON DANGKY
DECLARE
BEGIN
    MERGE INTO class_grade_summary cgs
    USING (
        SELECT 
            MALOP,
            COUNT(DIEM) AS so_sv,
            ROUND(AVG(DIEM), 2) AS diem_tb,
            MAX(DIEM) AS diem_cao_nhat,
            MIN(DIEM) AS diem_thap_nhat
        FROM DANGKY
        WHERE DIEM IS NOT NULL
        GROUP BY MALOP
    ) src
    ON (cgs.classid = src.MALOP)
    WHEN MATCHED THEN
        UPDATE SET
            so_sv = src.so_sv,
            diem_tb = src.diem_tb,
            diem_cao_nhat = src.diem_cao_nhat,
            diem_thap_nhat = src.diem_thap_nhat,
            cap_nhat_luc = SYSDATE
    WHEN NOT MATCHED THEN
        INSERT (classid, so_sv, diem_tb, diem_cao_nhat, diem_thap_nhat, cap_nhat_luc)
        VALUES (src.MALOP, src.so_sv, src.diem_tb, src.diem_cao_nhat, src.diem_thap_nhat, SYSDATE);
END;
/


UPDATE DANGKY 
SET DIEM = 90 
WHERE MALOP = 301;

COMMIT;

SELECT * FROM class_grade_summary;
--------------------------------BAI 4
CREATE OR REPLACE VIEW vw_instructor_workload AS
SELECT gv.MAGV,
       gv.HO || ' ' || gv.TEN AS ho_ten,
       COUNT(DISTINCT lh.MALOP) AS so_lop,
       COUNT(dk.MASV) AS tong_sv,
       ROUND(AVG(dk.DIEM), 2) AS diem_tb_chung,
       CASE
           WHEN COUNT(DISTINCT lh.MALOP) >= 3 THEN 'Ban nhieu'
           WHEN COUNT(DISTINCT lh.MALOP) = 2 THEN 'Binh thuong'
           ELSE 'Nhe nhang'
       END AS muc_ban
FROM GIANGVIEN gv
LEFT JOIN LOPHOC lh ON gv.MAGV = lh.MAGV
LEFT JOIN DANGKY dk ON lh.MALOP = dk.MALOP
GROUP BY gv.MAGV, gv.HO, gv.TEN
ORDER BY so_lop DESC;


CREATE OR REPLACE PROCEDURE print_system_report
IS
    v_so_mon NUMBER;
    v_so_lop NUMBER;
    v_so_sv NUMBER;
    v_so_gv NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_so_mon FROM MONHOC;
    SELECT COUNT(*) INTO v_so_lop FROM LOPHOC;
    SELECT COUNT(*) INTO v_so_sv FROM SINHVIEN;
    SELECT COUNT(*) INTO v_so_gv FROM GIANGVIEN;

    DBMS_OUTPUT.PUT_LINE('==============================');
    DBMS_OUTPUT.PUT_LINE(' BAO CAO HE THONG ');
    DBMS_OUTPUT.PUT_LINE('==============================');

    DBMS_OUTPUT.PUT_LINE('Tong mon hoc : ' || v_so_mon);
    DBMS_OUTPUT.PUT_LINE('Tong lop hoc : ' || v_so_lop);
    DBMS_OUTPUT.PUT_LINE('Tong sinh vien : ' || v_so_sv);
    DBMS_OUTPUT.PUT_LINE('Tong giao vien : ' || v_so_gv);

    DBMS_OUTPUT.PUT_LINE('------------------------------');

    DBMS_OUTPUT.PUT_LINE('THONG KE GIAO VIEN:');

    FOR rec IN (SELECT * FROM vw_instructor_workload) LOOP
        DBMS_OUTPUT.PUT_LINE(
            RPAD(rec.ho_ten, 25) ||
            ' | ' || rec.so_lop || ' lop' ||
            ' | ' || rec.tong_sv || ' SV' ||
            ' | DTB: ' || NVL(TO_CHAR(rec.diem_tb_chung), '--') ||
            ' | ' || rec.muc_ban
        );
    END LOOP;

    DBMS_OUTPUT.PUT_LINE('------------------------------');

    DBMS_OUTPUT.PUT_LINE('TOP 3 MON HOC:');

   FOR rec IN (SELECT * FROM vw_top_courses WHERE hang <= 3) LOOP
    DBMS_OUTPUT.PUT_LINE(
        rec.hang || '. ' ||
        rec.TENMH ||
        ' - ' || rec.tong_dk || ' luot'
    );
END LOOP;
END;
/

SET SERVEROUTPUT ON;

BEGIN
  print_system_report;
END;
/